# 帧率监测（FPS Monitor）

一个 Android 悬浮窗实时帧率监测 App，针对「指定应用/游戏」显示实时 FPS，注重低功耗。

## 功能

- 悬浮窗实时显示目标应用的 FPS，可拖动、记住位置、按帧率变色（绿/黄/红）
- 双引擎：
  - **Shizuku 引擎（低功耗，推荐）**：读系统 `SurfaceFlinger`/`gfxinfo` 帧时间戳，几乎不耗电
  - **屏幕捕捉引擎（零设置，功耗较高）**：MediaProjection 截屏 + 帧差异检测，无需 Shizuku
- 省电：熄屏自动暂停、省电模式（采样频率减半）、低分辨率捕捉

## 环境要求

- Android Studio（Koala / 2024.1 或更新）+ JDK 17
- 目标设备 Android 8.0（API 26）及以上

## 构建

1. 用 Android Studio 打开本目录（`FpsMonitor/`）
2. 等待 Gradle 同步完成（会自动下载 Gradle 8.2 与依赖）
3. `Build → Build APK(s)` 或直接运行到真机

## 使用步骤

### 方式一：Shizuku（低功耗，推荐）

1. 安装并启动 [Shizuku](https://shizuku.rikka.app/)（Play 商店 / GitHub 均可下载）
2. Shizuku 里「通过无线调试启动」（Android 11+ 无需电脑，跟着提示打开系统开发者选项的“无线调试”即可）
3. 打开本 App → `授权 Shizuku` → `选择应用` → `开始监测`
4. 第一次会请求「悬浮窗权限」，允许即可

> Shizuku 只需首次用「无线调试」激活一次，之后本 App 读帧数据几乎零功耗。

### 方式二：屏幕捕捉（零设置回退）

不装 Shizuku 时，点「开始监测」会自动弹出系统「屏幕捕捉」授权，允许后即可测量。
缺点：持续截屏，功耗明显更高，且每次开始都要重新授权一次。

## 功耗说明

| 引擎 | 原理 | 功耗 | 前提 |
|---|---|---|---|
| Shizuku | 轮询 `dumpsys SurfaceFlinger --latency` / `gfxinfo` | 很低 | 一次性无线调试激活 |
| MediaProjection | 低分辨率截屏 + 16x16 抽样哈希比对 | 中高 | 每次开始授权一次 |

省电开关建议全开：熄屏暂停、省电模式、低分辨率捕捉。

## 已知限制

- **纯普通用户（无 root / 无 ADB / 无 Shizuku）测量其它 App 的 FPS 只能靠截屏**，这是 Android 系统限制，无法做到既精准又零功耗；这也是本 App 默认推荐 Shizuku 的原因。
- Shizuku 引擎优先匹配 `SurfaceFlinger` 图层；若目标应用处于后台/未渲染，FPS 会显示为 0。
- 部分厂商 ROM 对悬浮窗/后台服务有额外限制，如测量中断请把本 App 加入「电池优化白名单 / 自启动」。

## 权限说明

- `SYSTEM_ALERT_WINDOW`：悬浮窗
- `FOREGROUND_SERVICE*`：前台服务保持监测存活
- `POST_NOTIFICATIONS`：前台服务通知（Android 13+）
- `QUERY_ALL_PACKAGES`：列出已安装应用供选择

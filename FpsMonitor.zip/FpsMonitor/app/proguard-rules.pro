# 当前 release 未开启混淆，保持默认即可。
-keep class rikka.shizuku.** { *; }

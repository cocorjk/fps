package com.fpsmonitor.app.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.fpsmonitor.app.R
import com.fpsmonitor.app.prefs.Settings

/**
 * 可拖动的帧率悬浮窗：负责 WindowManager 的添加/移除/拖动与文本刷新。
 */
class OverlayManager(private val context: Context) {

    private val windowManager = context.getSystemService(WindowManager::class.java)
    private var root: View? = null
    private var text: TextView? = null
    private var shown = false

    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    )

    private var initialX = 0
    private var initialY = 0
    private var touchStartX = 0f
    private var touchStartY = 0f
    private var dragging = false

    init {
        params.gravity = Gravity.TOP or Gravity.START
    }

    fun show() {
        if (shown) return
        val v = LayoutInflater.from(context).inflate(R.layout.overlay_fps, null)
        val tv = v.findViewById<TextView>(R.id.overlay_text)
        root = v
        text = tv

        val savedX = Settings.getOverlayX(context)
        val savedY = Settings.getOverlayY(context)
        if (savedX >= 0f && savedY >= 0f) {
            val dm = context.resources.displayMetrics
            params.x = (savedX * dm.widthPixels).toInt()
            params.y = (savedY * dm.heightPixels).toInt()
        }

        v.setOnTouchListener { view, event -> onTouch(view, event) }
        try {
            windowManager.addView(v, params)
            shown = true
        } catch (_: Throwable) {
        }
    }

    fun hide() {
        if (!shown) return
        root?.let { try { windowManager.removeView(it) } catch (_: Throwable) {} }
        root = null
        text = null
        shown = false
    }

    fun update(fps: Double, label: String?) {
        val tv = text ?: return
        val sb = StringBuilder()
        sb.append(String.format("%.0f", fps.coerceAtLeast(0.0)))
        if (Settings.getShowLabel(context) && !label.isNullOrBlank()) {
            sb.append('\n').append(label)
        }
        tv.text = sb.toString()
        tv.setTextColor(colorFor(fps))
    }

    private fun colorFor(fps: Double): Int = when {
        fps >= 55.0 -> Color.rgb(0x4C, 0xAF, 0x50) // 绿：流畅
        fps >= 30.0 -> Color.rgb(0xFF, 0xB3, 0x00) // 黄：一般
        else -> Color.rgb(0xF4, 0x43, 0x36)        // 红：卡顿
    }

    private fun onTouch(view: View, event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialX = params.x
                initialY = params.y
                touchStartX = event.rawX
                touchStartY = event.rawY
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (event.rawX - touchStartX).toInt()
                val dy = (event.rawY - touchStartY).toInt()
                if (Math.abs(dx) > 4 || Math.abs(dy) > 4) dragging = true
                if (dragging) {
                    params.x = initialX + dx
                    params.y = initialY + dy
                    try { windowManager.updateViewLayout(view, params) } catch (_: Throwable) {}
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    val dm = context.resources.displayMetrics
                    Settings.setOverlayPos(
                        context,
                        params.x.toFloat() / dm.widthPixels,
                        params.y.toFloat() / dm.heightPixels
                    )
                }
                return dragging
            }
        }
        return false
    }
}

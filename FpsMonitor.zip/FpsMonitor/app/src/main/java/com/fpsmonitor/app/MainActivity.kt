package com.fpsmonitor.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.fpsmonitor.app.core.ShizukuFpsEngine
import com.fpsmonitor.app.databinding.ActivityMainBinding
import com.fpsmonitor.app.model.AppInfo
import com.fpsmonitor.app.overlay.FpsOverlayService
import com.fpsmonitor.app.prefs.Settings
import com.fpsmonitor.app.util.AppListLoader
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var apps: List<AppInfo> = emptyList()

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                FpsOverlayService.startWithProjection(this, result.resultCode, result.data!!)
            } else {
                Toast.makeText(this, "已取消屏幕捕捉授权", Toast.LENGTH_SHORT).show()
            }
        }

    private val notifPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { code, _ ->
        if (code == SHIZUKU_PERM_CODE) runOnUiThread { refreshStatus() }
    }

    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { refreshStatus() } }
    private val binderDeadListener = Shizuku.OnBinderDeadListener { runOnUiThread { refreshStatus() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupIntervalSpinner()
        setupSwitches()
        setupButtons()
        refreshTarget()
        refreshStatus()

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
        refreshStatus()
    }

    override fun onPause() {
        super.onPause()
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
    }

    private fun setupButtons() {
        binding.btnPickApp.setOnClickListener { showAppPicker() }

        binding.btnOverlayPermission.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(
                        AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } else {
                Toast.makeText(this, "悬浮窗权限已授予", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnShizukuPermission.setOnClickListener {
            when {
                !Shizuku.pingBinder() ->
                    Toast.makeText(this, "Shizuku 未运行，请先安装并启动 Shizuku（见 README）", Toast.LENGTH_LONG).show()
                Shizuku.isPreV11() || Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED ->
                    Toast.makeText(this, "Shizuku 已授权", Toast.LENGTH_SHORT).show()
                else -> Shizuku.requestPermission(SHIZUKU_PERM_CODE)
            }
        }

        binding.btnStart.setOnClickListener { startMonitoring() }
        binding.btnStop.setOnClickListener { FpsOverlayService.stop(this) }
    }

    private fun setupSwitches() {
        binding.switchShowLabel.isChecked = Settings.getShowLabel(this)
        binding.switchSuspendOff.isChecked = Settings.getSuspendOnScreenOff(this)
        binding.switchBatterySave.isChecked = Settings.getBatterySave(this)
        binding.switchLowRes.isChecked = Settings.getLowRes(this)

        binding.switchShowLabel.setOnCheckedChangeListener { _, v -> Settings.setShowLabel(this, v) }
        binding.switchSuspendOff.setOnCheckedChangeListener { _, v -> Settings.setSuspendOnScreenOff(this, v) }
        binding.switchBatterySave.setOnCheckedChangeListener { _, v -> Settings.setBatterySave(this, v) }
        binding.switchLowRes.setOnCheckedChangeListener { _, v -> Settings.setLowRes(this, v) }
    }

    private fun setupIntervalSpinner() {
        val labels = listOf("0.5 秒", "1 秒（推荐）", "2 秒", "3 秒")
        val values = listOf(500L, 1000L, 2000L, 3000L)
        binding.spinnerInterval.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val idx = values.indexOf(Settings.getRawIntervalMs(this)).let { if (it < 0) 1 else it }
        binding.spinnerInterval.setSelection(idx)
        binding.spinnerInterval.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                Settings.setIntervalMs(this@MainActivity, values[position])
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun showAppPicker() {
        apps = AppListLoader.loadLaunchableApps(this)
        if (apps.isEmpty()) {
            Toast.makeText(this, "未找到可监测的应用", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = apps.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("选择要监测的应用")
            .setItems(labels) { _, which ->
                val app = apps[which]
                Settings.setTarget(this, app.packageName, app.label)
                refreshTarget()
                refreshStatus()
            }
            .show()
    }

    private fun startMonitoring() {
        if (Settings.getTargetPackage(this) == null) {
            Toast.makeText(this, "请先选择要监测的应用", Toast.LENGTH_SHORT).show()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先授予悬浮窗权限", Toast.LENGTH_SHORT).show()
            return
        }
        if (ShizukuFpsEngine.isShizukuReady()) {
            FpsOverlayService.startWithShizuku(this)
        } else {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projectionLauncher.launch(mpm.createScreenCaptureIntent())
        }
    }

    private fun refreshTarget() {
        val pkg = Settings.getTargetPackage(this)
        binding.textTarget.text = if (pkg == null) {
            "未选择应用"
        } else {
            "目标：${Settings.getTargetLabel(this)}\n（$pkg）"
        }
    }

    private fun refreshStatus() {
        val shizukuReady = ShizukuFpsEngine.isShizukuReady()
        binding.statusShizuku.text =
            if (shizukuReady) "Shizuku：已就绪（低功耗引擎可用）" else "Shizuku：未连接 / 未授权"
        binding.statusOverlay.text =
            if (Settings.canDrawOverlays(this)) "悬浮窗权限：已授予" else "悬浮窗权限：未授予"
        binding.textEngineHint.text =
            if (shizukuReady) "当前引擎：Shizuku（低功耗）" else "当前引擎：屏幕捕捉（功耗较高，建议授权 Shizuku）"
        binding.btnStart.isEnabled =
            Settings.getTargetPackage(this) != null &&
                (shizukuReady || Settings.canDrawOverlays(this))
    }

    companion object {
        private const val SHIZUKU_PERM_CODE = 100
    }
}

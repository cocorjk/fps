package com.fpsmonitor.app.core

/** 每秒帧数（FPS）采样回调，值可能为 0（无新帧 / 无数据）。 */
typealias FpsCallback = (fps: Double) -> Unit

/**
 * 帧率测量引擎的统一接口。
 * 目前有两种实现：
 *  - [ShizukuFpsEngine]：低功耗，读取系统帧时间戳（推荐）
 *  - [MediaProjectionFpsEngine]：无需 Shizuku，屏幕捕捉 + 帧差异检测（功耗较高）
 */
interface FpsEngine {
    fun start(callback: FpsCallback)
    fun stop()
    fun isRunning(): Boolean
}

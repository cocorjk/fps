package com.fpsmonitor.app.core

import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.fpsmonitor.app.prefs.Settings
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

/**
 * 低功耗引擎：借助 Shizuku（shell 权限）读取系统的帧时间戳，而不是截屏。
 *
 * 主方法：`dumpsys SurfaceFlinger --latency <layer>`，直接拿到每个提交帧的时间戳，
 * 对游戏 / SurfaceView 这类真正高频渲染的应用最准。
 * 回退方法：`dumpsys gfxinfo <pkg>` 的 "Total frames rendered" 差值，覆盖普通 UI 应用。
 */
class ShizukuFpsEngine(
    private val context: Context,
    private val targetPackage: String
) : FpsEngine {

    companion object {
        private const val TAG = "ShizukuFpsEngine"

        /** Shizuku 服务在线且本应用已获授权。 */
        fun isShizukuReady(): Boolean =
            Shizuku.pingBinder() &&
                (Shizuku.isPreV11() || Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED)
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()

    @Volatile private var running = false
    private var callback: FpsCallback? = null
    private var layerName: String? = null
    private var lastTotalFrames = -1L

    override fun start(callback: FpsCallback) {
        this.callback = callback
        running = true
        layerName = null
        lastTotalFrames = -1L
        executor.execute { loop() }
    }

    override fun stop() {
        running = false
    }

    override fun isRunning() = running

    private fun loop() {
        // 首次先清空历史帧数据，避免第一帧把开机以来的所有帧都算进去
        try {
            resolveLayer()?.let { shell("dumpsys SurfaceFlinger --latency-clear $it") }
        } catch (_: Throwable) {
        }

        while (running) {
            try {
                val fps = sample()
                val cb = callback
                if (cb != null) mainHandler.post { cb(fps) }
            } catch (t: Throwable) {
                Log.w(TAG, "采样失败", t)
            }
            try {
                Thread.sleep(Settings.getIntervalMs(context))
            } catch (_: InterruptedException) {
                break
            }
        }
    }

    private fun sample(): Double {
        val layer = resolveLayer()
        if (layer == null) return fallbackGfxInfo()

        val raw = shell("dumpsys SurfaceFlinger --latency $layer")
        shell("dumpsys SurfaceFlinger --latency-clear $layer")

        if (raw.isBlank() ||
            raw.contains("no layer", ignoreCase = true) ||
            raw.contains("not found", ignoreCase = true)
        ) {
            layerName = null // 图层可能已重建，下次重新解析
            return 0.0
        }

        val count = countFrameTimestamps(raw)
        return count * 1000.0 / Settings.getIntervalMs(context)
    }

    private fun fallbackGfxInfo(): Double {
        val out = shell("dumpsys gfxinfo $targetPackage")
        val marker = "Total frames rendered:"
        val total = out.lineSequence()
            .mapNotNull { line ->
                val i = line.indexOf(marker)
                if (i >= 0) line.substring(i + marker.length).trim().toLongOrNull() else null
            }
            .firstOrNull() ?: return 0.0

        val prev = lastTotalFrames
        lastTotalFrames = total
        if (prev < 0) return 0.0
        return (total - prev).coerceAtLeast(0) * 1000.0 / Settings.getIntervalMs(context)
    }

    private fun resolveLayer(): String? {
        if (layerName == null) {
            val list = shell("dumpsys SurfaceFlinger --list")
            layerName = list.lineSequence()
                .map { it.trim() }
                .firstOrNull { it.isNotEmpty() && it.contains(targetPackage) }
        }
        return layerName
    }

    /** 统计输出中有效的帧时间戳数量（纳秒级 Unix 时间戳，远大于刷新周期）。 */
    private fun countFrameTimestamps(output: String): Int {
        var count = 0
        for (line in output.lineSequence()) {
            val t = line.trim().split(Regex("\\s+")).firstOrNull()?.toLongOrNull()
            if (t != null && t > 1_000_000_000_000L) count++
        }
        return count
    }

    private fun shell(command: String): String {
        // 以 shell 身份执行，stderr 合并到 stdout，避免缓冲区死锁
        val process = Shizuku.newProcess(arrayOf("sh", "-c", "$command 2>&1"), null, null)
        return process.inputStream.bufferedReader().use { it.readText() }
            .also { process.waitFor() }
    }
}

package com.fpsmonitor.app.prefs

import android.content.Context

/**
 * 简单的 SharedPreferences 封装，集中管理所有可配置项。
 */
object Settings {

    private const val FILE = "fps_monitor_settings"

    private const val KEY_PKG = "target_package"
    private const val KEY_LABEL = "target_label"
    private const val KEY_INTERVAL = "interval_ms"
    private const val KEY_BATTERY_SAVE = "battery_save"
    private const val KEY_SUSPEND_OFF = "suspend_on_screen_off"
    private const val KEY_SHOW_LABEL = "show_label"
    private const val KEY_LOW_RES = "low_res"
    private const val KEY_OVERLAY_X = "overlay_x"
    private const val KEY_OVERLAY_Y = "overlay_y"

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ---- 目标应用 ----
    fun getTargetPackage(c: Context): String? = sp(c).getString(KEY_PKG, null)
    fun getTargetLabel(c: Context): String = sp(c).getString(KEY_LABEL, null) ?: "未选择"
    fun setTarget(c: Context, pkg: String, label: String) =
        sp(c).edit().putString(KEY_PKG, pkg).putString(KEY_LABEL, label).apply()

    // ---- 采样间隔 ----
    fun getRawIntervalMs(c: Context): Long = sp(c).getLong(KEY_INTERVAL, 1000L)

    /** 实际采样间隔：省电模式下翻倍，上限 4 秒。 */
    fun getIntervalMs(c: Context): Long {
        val base = getRawIntervalMs(c)
        return if (getBatterySave(c)) (base * 2).coerceAtMost(4000L) else base
    }

    fun setIntervalMs(c: Context, v: Long) = sp(c).edit().putLong(KEY_INTERVAL, v).apply()

    // ---- 省电 / 行为开关 ----
    fun getBatterySave(c: Context): Boolean = sp(c).getBoolean(KEY_BATTERY_SAVE, true)
    fun setBatterySave(c: Context, v: Boolean) = sp(c).edit().putBoolean(KEY_BATTERY_SAVE, v).apply()

    fun getSuspendOnScreenOff(c: Context): Boolean = sp(c).getBoolean(KEY_SUSPEND_OFF, true)
    fun setSuspendOnScreenOff(c: Context, v: Boolean) = sp(c).edit().putBoolean(KEY_SUSPEND_OFF, v).apply()

    fun getShowLabel(c: Context): Boolean = sp(c).getBoolean(KEY_SHOW_LABEL, true)
    fun setShowLabel(c: Context, v: Boolean) = sp(c).edit().putBoolean(KEY_SHOW_LABEL, v).apply()

    /** 仅屏幕捕捉引擎使用：更低的捕捉分辨率进一步省电。 */
    fun getLowRes(c: Context): Boolean = sp(c).getBoolean(KEY_LOW_RES, false)
    fun setLowRes(c: Context, v: Boolean) = sp(c).edit().putBoolean(KEY_LOW_RES, v).apply()

    // ---- 悬浮窗位置（按屏幕比例 0..1 存储） ----
    fun getOverlayX(c: Context): Float = sp(c).getFloat(KEY_OVERLAY_X, -1f)
    fun getOverlayY(c: Context): Float = sp(c).getFloat(KEY_OVERLAY_Y, -1f)
    fun setOverlayPos(c: Context, x: Float, y: Float) =
        sp(c).edit().putFloat(KEY_OVERLAY_X, x).putFloat(KEY_OVERLAY_Y, y).apply()

    fun canDrawOverlays(c: Context): Boolean = android.provider.Settings.canDrawOverlays(c)
}

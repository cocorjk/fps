package com.fpsmonitor.app.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.fpsmonitor.app.MainActivity
import com.fpsmonitor.app.R
import com.fpsmonitor.app.core.FpsEngine
import com.fpsmonitor.app.core.MediaProjectionFpsEngine
import com.fpsmonitor.app.core.ShizukuFpsEngine
import com.fpsmonitor.app.prefs.Settings

/**
 * 前台服务：持有悬浮窗 + FPS 引擎，负责其生命周期。
 * 熄屏自动暂停、亮屏恢复（省电）。
 */
class FpsOverlayService : Service() {

    companion object {
        const val ACTION_START = "com.fpsmonitor.app.action.START"
        const val ACTION_STOP = "com.fpsmonitor.app.action.STOP"
        const val EXTRA_USE_SHIZUKU = "extra_use_shizuku"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val CHANNEL_ID = "fps_monitor_channel"
        const val NOTIFICATION_ID = 1001

        fun startWithShizuku(context: Context) {
            context.startForegroundService(
                Intent(context, FpsOverlayService::class.java)
                    .setAction(ACTION_START)
                    .putExtra(EXTRA_USE_SHIZUKU, true)
            )
        }

        fun startWithProjection(context: Context, resultCode: Int, data: Intent) {
            context.startForegroundService(
                Intent(context, FpsOverlayService::class.java)
                    .setAction(ACTION_START)
                    .putExtra(EXTRA_USE_SHIZUKU, false)
                    .putExtra(EXTRA_RESULT_CODE, resultCode)
                    .putExtra(EXTRA_RESULT_DATA, data)
            )
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, FpsOverlayService::class.java).setAction(ACTION_STOP)
            )
        }
    }

    private var engine: FpsEngine? = null
    private var overlay: OverlayManager? = null
    private var projection: MediaProjection? = null
    private var useShizuku = true
    private var paused = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> pause()
                Intent.ACTION_SCREEN_ON -> resume()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        overlay = OverlayManager(this)
        createChannel()
        registerReceiver(
            screenReceiver,
            IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopMonitoring()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> startMonitoring(intent)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        unregisterReceiver(screenReceiver)
        stopMonitoring()
        super.onDestroy()
    }

    private fun startMonitoring(intent: Intent) {
        stopMonitoring()

        val pkg = Settings.getTargetPackage(this)
        if (pkg.isNullOrBlank()) {
            stopSelf()
            return
        }

        useShizuku = intent.getBooleanExtra(EXTRA_USE_SHIZUKU, true)
        val label = Settings.getTargetLabel(this)

        // Android 14 要求：先以 mediaProjection 类型启动前台服务，再 getMediaProjection()
        startForegroundWithType(label, useShizuku)

        if (!useShizuku) {
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
            val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            } else {
                @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
            }
            projection = createProjection(resultCode, data)
            if (projection == null) {
                stopSelf()
                return
            }
        }

        startEngine()
    }

    private fun startEngine() {
        val pkg = Settings.getTargetPackage(this) ?: return
        val label = Settings.getTargetLabel(this)

        val eng: FpsEngine = if (useShizuku) {
            ShizukuFpsEngine(this, pkg)
        } else {
            val proj = projection ?: run { stopSelf(); return }
            MediaProjectionFpsEngine(this, proj) { stopSelf() }
        }
        engine = eng
        overlay?.show()
        eng.start { fps -> overlay?.update(fps, label) }
    }

    private fun pause() {
        if (!Settings.getSuspendOnScreenOff(this)) return
        if (paused) return
        paused = true
        engine?.stop()
        engine = null
    }

    private fun resume() {
        if (!paused) return
        paused = false
        startEngine()
    }

    private fun stopMonitoring() {
        engine?.stop()
        engine = null
        overlay?.hide()
        projection?.stop()
        projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun createProjection(resultCode: Int, data: Intent?): MediaProjection? {
        if (resultCode < 0 || data == null) return null
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        return try {
            mpm.getMediaProjection(resultCode, data)
        } catch (_: Throwable) {
            null
        }
    }

    private fun startForegroundWithType(label: String?, useShizuku: Boolean) {
        val type = when {
            useShizuku && Build.VERSION.SDK_INT >= 34 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            useShizuku -> 0
            Build.VERSION.SDK_INT >= 29 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            else -> 0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(label), type)
    }

    private fun buildNotification(label: String?): Notification {
        val pending = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("帧率监测运行中")
            .setContentText("目标：${label ?: "未选择"}")
            .setOngoing(true)
            .setContentIntent(pending)
            .build()
    }

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(CHANNEL_ID, "帧率监测", NotificationManager.IMPORTANCE_LOW)
        nm.createNotificationChannel(channel)
    }
}

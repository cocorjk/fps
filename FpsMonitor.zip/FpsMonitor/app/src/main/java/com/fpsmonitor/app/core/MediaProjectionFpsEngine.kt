package com.fpsmonitor.app.core

import android.content.Context
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.fpsmonitor.app.prefs.Settings
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 屏幕捕捉引擎（无需 Shizuku，但功耗更高）：
 * 通过 MediaProjection 镜像屏幕到低分辨率 ImageReader，
 * 对每帧做 16x16 的抽样哈希，检测「内容变化」来统计帧数。
 *
 * 省电手段：低分辨率捕捉、极小抽样网格、逐秒聚合上报。
 */
class MediaProjectionFpsEngine(
    private val context: Context,
    private val projection: MediaProjection,
    private val onProjectionStopped: () -> Unit
) : FpsEngine {

    companion object {
        private const val TAG = "MediaProjectionFps"
        private const val FLUSH_MS = 1000L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)

    private var callback: FpsCallback? = null
    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var lastSignature: Long? = null
    private var frameCount = 0

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            mainHandler.post { onProjectionStopped() }
        }
    }

    private val flushRunnable = object : Runnable {
        override fun run() {
            if (!running.get()) return
            val cb = callback
            if (cb != null) {
                val fps = frameCount.toDouble()
                mainHandler.post { cb(fps) }
            }
            frameCount = 0
            mainHandler.postDelayed(this, FLUSH_MS)
        }
    }

    override fun start(callback: FpsCallback) {
        this.callback = callback
        if (!running.compareAndSet(false, true)) return

        projection.registerCallback(projectionCallback, mainHandler)

        val metrics = context.resources.displayMetrics
        // 降低捕捉分辨率以省电：普通 50%，低分辨率模式 25%
        val scale = if (Settings.getLowRes(context)) 0.25f else 0.5f
        val width = (metrics.widthPixels * scale).toInt().coerceAtLeast(1)
        val height = (metrics.heightPixels * scale).toInt().coerceAtLeast(1)

        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader.setOnImageAvailableListener({ r -> processFrame(r) }, mainHandler)
        imageReader = reader

        try {
            virtualDisplay = projection.createVirtualDisplay(
                "FpsMonitor",
                width, height, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, null
            )
        } catch (t: Throwable) {
            Log.e(TAG, "createVirtualDisplay failed", t)
            reader.close()
            imageReader = null
            running.set(false)
            mainHandler.post { onProjectionStopped() }
            return
        }

        frameCount = 0
        lastSignature = null
        mainHandler.postDelayed(flushRunnable, FLUSH_MS)
    }

    override fun stop() {
        if (!running.compareAndSet(true, false)) return
        mainHandler.removeCallbacks(flushRunnable)
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        try { imageReader?.close() } catch (_: Throwable) {}
        try { projection.unregisterCallback(projectionCallback) } catch (_: Throwable) {}
        virtualDisplay = null
        imageReader = null
        lastSignature = null
    }

    override fun isRunning() = running.get()

    private fun processFrame(reader: ImageReader) {
        if (!running.get()) return
        val image = try { reader.acquireLatestImage() } catch (_: Throwable) { null } ?: return
        try {
            val sig = signature(image)
            val last = lastSignature
            lastSignature = sig
            if (last != null && sig != last) frameCount++
        } finally {
            image.close()
        }
    }

    /** 16x16 抽样哈希：极低 CPU 开销，足以区分画面是否变化。 */
    private fun signature(image: Image): Long {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val w = image.width
        val h = image.height
        val samples = 16
        var hash = 0L
        for (y in 0 until samples) {
            val row = (y.toLong() * h / samples).toInt().coerceAtMost(h - 1)
            val rowOffset = row * rowStride
            for (x in 0 until samples) {
                val col = (x.toLong() * w / samples).toInt().coerceAtMost(w - 1)
                val idx = rowOffset + col * pixelStride
                val v = buffer.get(idx).toInt() and 0xFF
                hash = hash * 31 + v
            }
        }
        return hash
    }
}
